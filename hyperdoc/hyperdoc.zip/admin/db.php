<?php
	
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "imk";

$db = new mysqli($hostname, $username, $password, $dbname);
?>