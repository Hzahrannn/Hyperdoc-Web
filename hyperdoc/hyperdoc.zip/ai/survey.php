<?php

$panas =$_POST['panas'];
$tinggi = $_POST['tinggi'];
$nafsu =$_POST['nafsu'];
$mual = $_POST['mual'];
?>
<?php
									include "db.php";
									$sql = "SELECT * FROM kuis where panas like '%$panas%' and tinggi like '%$tinggi%' and nafsu like '%$nafsu%' and mual like '%$mual%'";
									$result = $conn->query($sql);
									?>

									<?php while($row = $result->fetch_assoc()){
									?>
                                    
										<p>kemungkinan Penyakit anda adalah <?php echo $row["penyakit"]; ?></p>
										<br>
										<a href="index.php">Kembali Ke Home </a>
										
									<?php }
									?>





